import { useEffect, useMemo, useState } from 'react';
import { io, type Socket } from 'socket.io-client';

type Status = 'lobby' | 'playing' | 'finished';
type MetricKey = 'gdp' | 'inflation' | 'unemployment' | 'happiness' | 'debt' | 'equality';
type PlayerState = Record<MetricKey, number>;
type Choice = { key: string; title: string; desc: string; delta: Partial<PlayerState> };
type Player = {
  id: string;
  name: string;
  connected: boolean;
  hasChosen: boolean;
  score: number;
  state: PlayerState;
};
type Room = {
  code: string;
  status: Status;
  year: number;
  totalYears: number;
  event: {
    chapter: number;
    title: string;
    desc: string;
    question: string;
    cause?: { playerName: string; answer: string } | null;
  };
  deadlineAt?: number | string | null;
  answerTimeMs?: number;
  serverTime?: number;
  players: Player[];
  results?: Array<{ name: string; score: number; state: PlayerState; choices: Array<{ title: string }> }>;
  isHost: boolean;
  myChoices: Choice[];
};
type Ack = { ok: boolean; code?: string; playerId?: string; resumeToken?: string; error?: string };
type Session = { code: string; resumeToken: string; name?: string };

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || window.location.origin;
const SESSION_KEY = 'unhingedEconomicsOnlineSession';
const metricLabels: Record<MetricKey, string> = {
  gdp: 'GDP',
  inflation: 'Inflation',
  unemployment: 'Unemployment',
  happiness: 'Happiness',
  debt: 'Debt',
  equality: 'Equality',
};

function readSession(): Session | null {
  try {
    const value = JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null');
    return value?.code && value?.resumeToken ? value : null;
  } catch {
    return null;
  }
}

function saveSession(code: string, resumeToken: string, name: string) {
  try {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({ code, resumeToken, name }));
  } catch {
    // The live socket still works if sessionStorage is unavailable.
  }
}

function clearSession() {
  try {
    sessionStorage.removeItem(SESSION_KEY);
  } catch {
    // Nothing else to clear.
  }
}

function formatMoney(value: number) {
  return value >= 1000 ? `$${(value / 1000).toFixed(2)}T` : `$${Math.round(value)}B`;
}

function formatTimer(deadlineAt: number | string | null | undefined, serverClockOffset: number) {
  if (!deadlineAt) return '';
  const leftMs = Number(deadlineAt) + serverClockOffset - Date.now();
  const seconds = Math.max(0, Math.ceil(leftMs / 1000));
  return seconds > 0 ? `${seconds}s to answer` : 'Time is up · resolving unanswered turns…';
}

function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [socketReady, setSocketReady] = useState(false);
  const [room, setRoom] = useState<Room | null>(null);
  const [myId, setMyId] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [serverClockOffset, setServerClockOffset] = useState(0);

  useEffect(() => {
    const client = io(SOCKET_URL, { path: '/api/socket.io', transports: ['websocket', 'polling'] });
    setSocket(client);
    const saved = readSession();
    client.on('connect', () => {
      setSocketReady(true);
      if (!saved) return;
      client.emit('room:resume', saved, (ack: Ack) => {
        if (ack?.ok && ack.playerId) {
          setMyId(ack.playerId);
          return;
        }
        clearSession();
        setNotice(ack?.error || 'Your saved room is no longer available.');
      });
    });
    client.on('disconnect', () => setSocketReady(false));
    client.on('connect_error', () => setNotice('Unable to connect to the game server. Retrying…'));
    client.on('room:update', (nextRoom: Room) => {
      setRoom(nextRoom);
      if (nextRoom.serverTime) setServerClockOffset(Date.now() - nextRoom.serverTime);
    });
    return () => {
      client.disconnect();
    };
  }, []);

  const call = (event: string, data: Record<string, unknown>) => new Promise<Ack>((resolve) => {
    if (!socket?.connected) {
      resolve({ ok: false, error: 'Connection lost. Reconnecting—try again in a moment.' });
      return;
    }
    socket.emit(event, data, (response: Ack) => resolve(response || { ok: false, error: 'The server returned an empty response.' }));
  });

  const enterRoom = async (kind: 'create' | 'join', name: string, code: string, totalYears: number) => {
    setNotice('');
    setBusy(true);
    const result = await call(kind === 'create' ? 'room:create' : 'room:join', kind === 'create' ? { name, totalYears } : { name, code });
    setBusy(false);
    if (!result.ok || !result.code || !result.resumeToken) {
      setNotice(result.error || 'The room could not be opened.');
      return;
    }
    setMyId(result.playerId || '');
    saveSession(result.code, result.resumeToken, name);
  };

  const startGame = async () => {
    setBusy(true);
    const result = await call('game:start', {});
    setBusy(false);
    if (!result.ok) setNotice(result.error || 'Only the host can start the game.');
  };

  const choose = async (choiceIndex: number) => {
    if (!room) return;
    setBusy(true);
    const result = await call('game:choose', { year: room.year, choiceIndex });
    setBusy(false);
    if (!result.ok) setNotice(result.error || 'That answer is no longer available.');
    else setNotice('');
  };

  const leaveRoom = () => {
    clearSession();
    setRoom(null);
    setMyId('');
    setNotice('');
  };

  return (
    <main>
      <p className="eyebrow">A deeply unserious policy simulator</p>
      <h1>UNHINGED<br />ECONOMICS<br />ONLINE</h1>
      <p className="tagline">economy based on your group chat</p>
      {!room ? (
        <Lobby
          busy={busy}
          connected={socketReady}
          notice={notice}
          session={readSession()}
          onCreate={(name, years) => enterRoom('create', name, '', years)}
          onJoin={(name, code) => enterRoom('join', name, code, 20)}
          onResume={() => {
            const saved = readSession();
            if (saved && socket) socket.emit('room:resume', saved);
          }}
        />
      ) : (
        <RoomView
          room={room}
          myId={myId}
          busy={busy}
          notice={notice}
          connected={socketReady}
          serverClockOffset={serverClockOffset}
          onStart={startGame}
          onChoose={choose}
          onLeave={leaveRoom}
        />
      )}
    </main>
  );
}

function Lobby({
  busy,
  connected,
  notice,
  session,
  onCreate,
  onJoin,
  onResume,
}: {
  busy: boolean;
  connected: boolean;
  notice: string;
  session: Session | null;
  onCreate: (name: string, years: number) => void;
  onJoin: (name: string, code: string) => void;
  onResume: () => void;
}) {
  const [name, setName] = useState(session?.name || '');
  const [joinName, setJoinName] = useState(session?.name || '');
  const [code, setCode] = useState('');
  const [years, setYears] = useState(20);

  return (
    <section className="panel" id="lobby" aria-labelledby="lobbyTitle" data-testid="panel-lobby">
      <h2 id="lobbyTitle">Create a room</h2>
      <form className="row" onSubmit={(event) => { event.preventDefault(); onCreate(name.trim(), years); }}>
        <label>Your name
          <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" maxLength={18} autoComplete="nickname" required data-testid="input-create-name" />
        </label>
        <label>Game length
          <select value={years} onChange={(event) => setYears(Number(event.target.value))} data-testid="select-game-length">
            <option value={10}>10 chapters</option>
            <option value={15}>15 chapters</option>
            <option value={20}>20 chapters</option>
          </select>
        </label>
        <button className="btn" disabled={busy || !connected} data-testid="button-create-room">{busy ? 'Opening…' : 'Create room'}</button>
      </form>
      <hr />
      <h2>Join a room</h2>
      <form className="row" onSubmit={(event) => { event.preventDefault(); onJoin(joinName.trim(), code.trim().toUpperCase()); }}>
        <label>Your name
          <input value={joinName} onChange={(event) => setJoinName(event.target.value)} placeholder="Your name" maxLength={18} autoComplete="nickname" required data-testid="input-join-name" />
        </label>
        <label>Room code
          <input className="room-code-input" value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="ROOM CODE" maxLength={6} required data-testid="input-room-code" />
        </label>
        <button className="btn light" disabled={busy || !connected} data-testid="button-join-room">Join room</button>
      </form>
      <p className="small">Up to 8 players. The room shares the first prompt, then a rotating player's answer determines the next chapter. No question or answer card repeats within a match.</p>
      <p className="connection" data-testid="status-connection">{connected ? 'Connected' : 'Connecting to the game server…'}</p>
      {session && (
        <div className="resume-box" data-testid="panel-resume">
          <span>Saved room <b>{session.code}</b> is available in this browser.</span>
          <button className="btn light" onClick={onResume} disabled={!connected} data-testid="button-resume-room">Resume room</button>
        </div>
      )}
      {notice && <Notice text={notice} />}
    </section>
  );
}

function RoomView({
  room,
  myId,
  busy,
  notice,
  connected,
  serverClockOffset,
  onStart,
  onChoose,
  onLeave,
}: {
  room: Room;
  myId: string;
  busy: boolean;
  notice: string;
  connected: boolean;
  serverClockOffset: number;
  onStart: () => void;
  onChoose: (index: number) => void;
  onLeave: () => void;
}) {
  const [timerTick, setTimerTick] = useState(Date.now());
  useEffect(() => {
    if (room.status !== 'playing') return undefined;
    const interval = window.setInterval(() => setTimerTick(Date.now()), 250);
    return () => window.clearInterval(interval);
  }, [room.status, room.deadlineAt]);

  const me = room.players.find((player) => player.id === myId);
  const orderedPlayers = useMemo(() => [...room.players].sort((a, b) => b.score - a.score), [room.players]);
  const timer = formatTimer(room.deadlineAt, serverClockOffset);
  void timerTick;

  return (
    <div id="room" data-testid="panel-room">
      <section className="panel room-header">
        <div className="room-title-row">
          <h2>Room lobby</h2>
          <div className="row compact">
            <button className="btn light" onClick={() => void navigator.clipboard?.writeText(`${window.location.origin}?room=${room.code}`)} data-testid="button-copy-invite">Copy invite</button>
            <button className="btn light" onClick={onLeave} data-testid="button-leave-room">Leave room</button>
          </div>
        </div>
        <div className="code" data-testid="text-room-code">{room.code}</div>
        <p>Share the invite with your friends. <span className="connection">{connected ? 'Connected' : 'Reconnecting…'}</span></p>
        <div className="players" aria-live="polite" data-testid="list-players">
          {room.players.map((player) => (
            <span className={player.id === myId ? 'player-chip current' : 'player-chip'} key={player.id} data-testid={`chip-player-${player.id}`}>
              {player.name} {player.connected ? 'online' : 'offline'}{player.hasChosen && room.status === 'playing' ? ' · filed' : ''}
            </span>
          ))}
        </div>
        <p className="small" data-testid="text-room-status">
          {room.status === 'lobby' ? 'Waiting for players. The host can start with 2 connected players.' : room.status === 'finished' ? 'Game finished — final standings are below.' : 'The next chapter is driven by a rotating player’s answer.'}
        </p>
        {room.status === 'lobby' && room.isHost && (
          <button className="btn" onClick={onStart} disabled={busy || room.players.filter((player) => player.connected).length < 2} data-testid="button-start-game">
            {busy ? 'Starting…' : 'Start game (host)'}
          </button>
        )}
        {room.status === 'lobby' && !room.isHost && <p className="small">Waiting for the host to start the game.</p>}
      </section>

      {room.status === 'finished' ? (
        <Results room={room} />
      ) : (
        <div className="grid">
          <section className="panel" aria-labelledby="chapter-title">
            <h2 id="chapter-title">CHAPTER {room.event.chapter} / {room.totalYears}</h2>
            <div className="event" data-testid="card-event">
              <span className="chapter-label">{room.event.cause ? `Because ${room.event.cause.playerName} chose…` : 'Opening scenario · shared by everyone'}</span>
              <b className="event-title" data-testid="text-event-title">{room.event.title}</b>
              <p>{room.event.desc}</p>
              {room.event.cause && <p className="story-bridge" data-testid="text-story-cause">“{room.event.cause.answer}”</p>}
              <p className="question" data-testid="text-event-question">{room.event.question}</p>
            </div>
            {room.status === 'playing' && <p className="timer" data-testid="text-timer">{timer}</p>}
            {room.status === 'playing' && <p className="game-note small">Everyone sees the same chapter. Your four answer cards are private and unique for this entire match. If time runs out, the server chooses one for you.</p>}
            {me && (
              <>
                <h3 data-testid="text-turn-state">
                  {room.status === 'lobby' ? 'Waiting for the host to start' : me.hasChosen ? 'Your answer is locked. Waiting for the other players…' : 'Choose what happens next'}
                </h3>
                <div data-testid="list-choices">
                  {room.status === 'playing' && !me.hasChosen && room.myChoices.map((choice, index) => (
                    <button className="choice" key={choice.key} onClick={() => onChoose(index)} disabled={busy || !connected} data-testid={`button-choice-${index}`}>
                      <b>{String.fromCharCode(65 + index)}) {choice.title}</b>
                      <span>{choice.desc}</span>
                      <small>{Object.entries(choice.delta).map(([key, value]) => `${Number(value) >= 0 ? '+' : ''}${value} ${metricLabels[key as MetricKey]}`).join(' · ')}</small>
                    </button>
                  ))}
                </div>
              </>
            )}
            {notice && <Notice text={notice} />}
          </section>
          <section className="panel">
            <h2>Your economy</h2>
            <div className="stats" data-testid="grid-metrics">
              {me && Object.entries(me.state).map(([key, value]) => (
                <div className="stat" key={key} data-testid={`metric-${key}`}>
                  <small>{metricLabels[key as MetricKey]}</small>
                  <b>{key === 'gdp' || key === 'debt' ? formatMoney(value) : key === 'happiness' || key === 'equality' ? Math.round(value) : `${value.toFixed(1)}%`}</b>
                </div>
              ))}
            </div>
            <h3>Live standings</h3>
            <Standings players={orderedPlayers} myId={myId} />
          </section>
        </div>
      )}
    </div>
  );
}

function Standings({ players, myId }: { players: Player[]; myId: string }) {
  return (
    <div className="scroll">
      <table data-testid="table-standings">
        <thead><tr><th>Player</th><th>GDP</th><th>Happiness</th><th>Score</th></tr></thead>
        <tbody>{players.map((player) => (
          <tr key={player.id}><td>{player.name}{player.id === myId ? ' (you)' : ''}</td><td>{formatMoney(player.state.gdp)}</td><td>{Math.round(player.state.happiness)}</td><td>{player.score}</td></tr>
        ))}</tbody>
      </table>
    </div>
  );
}

function Results({ room }: { room: Room }) {
  return (
    <section className="panel" data-testid="panel-results">
      <h2>Final results</h2>
      <p>The market survived you. Here is the official ranking of everyone who had a plan.</p>
      <div className="scroll">
        <table data-testid="table-results">
          <thead><tr><th>Rank</th><th>Player</th><th>Score</th><th>GDP</th><th>Happiness</th><th>Choices filed</th></tr></thead>
          <tbody>{(room.results || []).map((player, index) => (
            <tr key={`${player.name}-${index}`}><td>{index + 1}</td><td>{player.name}</td><td>{player.score}</td><td>{formatMoney(player.state.gdp)}</td><td>{Math.round(player.state.happiness)}</td><td>{player.choices.length}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </section>
  );
}

function Notice({ text }: { text: string }) {
  return <div className="notice" role="alert" data-testid="status-notice">{text}</div>;
}

export default App;