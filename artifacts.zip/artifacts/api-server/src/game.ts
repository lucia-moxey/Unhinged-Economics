// @ts-nocheck
import { createHash, randomBytes, randomInt, randomUUID } from "node:crypto";
import { Server } from "socket.io";

const TURN_TIME_MS = 30_000;
const MAX_PLAYERS = 8;
const CHOICES_PER_PLAYER = 4;
const ROOM_TTL_MS = 60 * 60_000;
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

const openingEvent = {
  chapter: 1,
  title: "THE MOON SENT AN ITEMIZED INVOICE",
  desc: "Earth owes back-pay for tides, moonlight, and several billion dramatic werewolf transformations. The invoice is stamped FINAL NOTICE in glitter.",
  question: "How will you settle the lunar bill without bankrupting Earth?",
  cause: null,
};

const storyChapters = [
  ["THE TREASURY ACCEPTED A VERY SPECIFIC PAYMENT", "The cabinet followed the plan exactly. Unfortunately, the plan made the moon think Earth had agreed to a long-term partnership.", "What do you do when your emergency fix becomes a binding lunar contract?"],
  ["THE CURRENCY FORMED A UNION", "The bills have elected representatives, a strike fund, and a surprisingly strong opinion about nap rooms.", "How do you negotiate with money that has organized against you?"],
  ["THE BUDGET WAS HANDED TO RACCOONS", "The new finance ministry arrived in tiny briefcases and presented a 900-page plan made entirely of snack wrappers.", "What is your economic response to the raccoon-led budget?"],
  ["THE CAPITAL IS UNDER SENTIENT SOUP", "The soup is legally classified as weather, keeps asking for a cabinet position, and is raining tiny crackers.", "How do you keep commerce moving through the soup emergency?"],
  ["ALL SPREADSHEETS DEVELOPED STAGE FRIGHT", "Whenever anyone opens a budget, the cells blush, hide their formulas, and whisper 'not today.'", "How will you get the country's numbers back on stage?"],
  ["THE NATIONAL DEBT STARTED CALLING PEOPLE", "It leaves voicemails at 3:17 a.m. and knows everyone's childhood nickname. The hold music is just a cash register sobbing.", "What do you promise the debt so it stops escalating the situation?"],
  ["THE STOCK MARKET BECAME A LITERAL MARKET", "Shares are now sold from folding tables by vendors who insist that volatility is a flavor.", "How do you regulate a financial exchange that has become open-air commerce?"],
  ["INFLATION ESCAPED INTO THE WILD", "Prices are multiplying in abandoned shopping carts. One sandwich now has a mortgage and a trusted advisor.", "What do you send after runaway prices before they reach the suburbs?"],
  ["THE CENTRAL BANK DECLARED INDEPENDENCE", "It has raised a flag, issued passports, and refuses to recognize the government's jurisdiction over interest rates.", "How do you bring a sovereign central bank back into the economy?"],
  ["EVERY RECEIPT BECAME A LEGAL WITNESS", "Receipts are testifying in court about impulse purchases, suspicious coupons, and one very ambitious office lunch.", "How do you keep the legal system from being buried under paper evidence?"],
  ["THE UNEMPLOYMENT OFFICE OPENED PORTALS", "Applicants are being routed to jobs in alternate dimensions. The benefits form now asks whether you have a preferred timeline.", "What is your labor-market plan when the workforce is leaving reality?"],
  ["THE GDP GREW A SECOND GDP", "The copy is smaller, louder, and insists it is the real economy. Both are demanding separate stimulus.", "Which economy gets the emergency resources, and how do you stop the other one rioting?"],
  ["TAXES BECAME A COMPETITIVE SPORT", "Citizens are sprinting through loopholes while commentators yell about deductions. The championship trophy is a locked filing cabinet.", "How do you make tax collection fair when everyone is trying to win?"],
  ["THE NATIONAL RESERVE WAS REPLACED BY A VENDING MACHINE", "It prints money only after receiving a sincere compliment and has begun charging a convenience fee for coins.", "How do you audit a vending machine that controls the money supply?"],
  ["THE PEOPLE DEMANDED A REFUND", "Millions of citizens have returned their receipts for the last fifteen decisions. The refund queue wraps around the capital.", "What do you offer the public when confidence has become a returnable item?"],
  ["THE LAST AUDIT FOUND ANOTHER AUDIT", "Behind the audit was a smaller audit, and behind that one was a note reading 'please do not continue.'", "How far down the accountability tunnel are you willing to go?"],
  ["THE MOON REQUESTED A CABINET SEAT", "It has tides, leverage, and a constituency of werewolves. The lunar ambassador is already rearranging the furniture.", "Do you give the moon political power, and what could possibly go wrong?"],
  ["THE ECONOMY FILED FOR EMOTIONAL DAMAGES", "The complaint names every rushed compromise, improvised fix, and suspiciously confident press conference.", "How do you defend the government's record when the economy is the plaintiff?"],
  ["THE FINAL BILL CAME DUE", "Every consequence has arrived at once: the soup is boiling, the raccoons are unionizing, and the moon has hired lawyers.", "What is your last, worst, best idea to keep the country technically solvent?"],
].map(([title, desc, question]) => ({ title, desc, question }));

const policies = [
  ["Replace the central bank with a goose-powered tuba", "Interest rates now move whenever the lead goose honks.", { gdp: 10, inflation: 1, happiness: 3, debt: 5, equality: 1 }],
  ["Print emergency money on haunted lasagna wrappers", "The wrappers are legal tender and occasionally whisper.", { gdp: 16, inflation: 5, happiness: 2, debt: 18, equality: 2 }],
  ["Appoint raccoons as Treasury goblins", "They find hidden snacks, if not hidden deficits.", { gdp: 9, inflation: 1, unemployment: -1, debt: 8, equality: 2 }],
  ["Give every household an emotional-support turnip", "The turnip has a tiny blanket and a suspiciously strong credit score.", { gdp: 5, happiness: 8, debt: 22, equality: 4 }],
  ["Move the entire budget into a suspiciously large piñata", "The cabinet promises not to swing at it until the audit is complete.", { gdp: -8, inflation: 2, happiness: 6, debt: 12, equality: 1 }],
  ["Make tax filing a televised karaoke tournament", "Deductions are awarded for pitch, rhythm, and emotional commitment.", { gdp: 7, happiness: 5, unemployment: -1, equality: 2 }],
  ["Declare a nationwide four-minute nap between meetings", "Productivity experts are baffled; office chairs are delighted.", { gdp: 4, happiness: 9, unemployment: -2, debt: 4, equality: 1 }],
  ["Auction the national debt to a time-traveling yard sale", "The buyer wants payments in future antique spoons.", { gdp: 12, inflation: 2, happiness: -1, debt: -12, equality: -1 }],
];

const twists = [
  ["with oversight from three unionized pigeons", "The pigeons demand proper hats and a guaranteed lunch break.", { gdp: 2, happiness: 2, debt: 3, equality: 1 }],
  ["funded by a haunted vending machine", "It dispenses grants after receiving a sincere compliment.", { gdp: 4, inflation: 1, happiness: 1, debt: 7 }],
  ["announced by a giant inflatable frog", "The frog's press conference is moving, if difficult to fact-check.", { gdp: 1, happiness: 4, unemployment: -1, equality: 1 }],
  ["enforced through interpretive dance", "The Supreme Court has not ruled on whether the finale is binding.", { gdp: -2, happiness: 3, inflation: -1, equality: 2 }],
];

const rooms = new Map();

const cleanName = (value) => String(value || "Player").trim().slice(0, 18) || "Player";
const baseState = () => ({ gdp: 1000, inflation: 3, unemployment: 5, happiness: 65, debt: 500, equality: 50 });
const makeCode = () => {
  let code;
  do code = Array.from({ length: 6 }, () => CODE_CHARS[randomInt(CODE_CHARS.length)]).join("");
  while (rooms.has(code));
  return code;
};
const shuffle = (items) => {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = randomInt(i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
};
const score = (player) => Math.round(player.state.gdp / 20 + player.state.happiness * 2 + player.state.equality + (100 - player.state.unemployment) + Math.max(0, 100 - player.state.inflation) - player.state.debt / 50 + player.choices.length * 8);

function applyChoice(player, choice, choiceIndex, year) {
  Object.entries(choice.delta).forEach(([key, value]) => {
    if (Object.hasOwn(player.state, key)) player.state[key] += value;
  });
  const state = player.state;
  state.gdp += state.gdp * (0.018 + (state.happiness - 60) * 0.00025 - (state.inflation > 8 ? (state.inflation - 8) * 0.001 : 0) - (state.debt > state.gdp ? 0.008 : 0));
  state.unemployment += state.gdp < 850 ? 1 : -0.2;
  state.inflation += (state.gdp > 1400 ? 0.25 : 0) + (state.inflation > 10 ? 0.3 : 0) - 0.2;
  state.debt += state.gdp < 900 ? 20 : 7;
  state.happiness += (state.unemployment < 5 ? 0.6 : -0.5) - (state.inflation > 10 ? 1 : 0);
  state.gdp = Math.max(100, Math.min(10_000, state.gdp));
  state.unemployment = Math.max(0, Math.min(50, state.unemployment));
  state.inflation = Math.max(-5, Math.min(90, state.inflation));
  state.debt = Math.max(0, Math.min(20_000, state.debt));
  state.happiness = Math.max(0, Math.min(100, state.happiness));
  state.equality = Math.max(0, Math.min(100, state.equality));
  player.lastChoice = choice;
  player.choices[year - 1] = { choiceIndex, title: choice.title, key: choice.key };
}

function makeChoices(room) {
  const deck = shuffle(policies.flatMap(([policy, policyDesc, policyDelta], policyIndex) => twists.map(([twist, twistDesc, twistDelta], twistIndex) => {
    const delta = {};
    for (const key of new Set([...Object.keys(policyDelta), ...Object.keys(twistDelta)])) delta[key] = (policyDelta[key] || 0) + (twistDelta[key] || 0);
    return {
      key: `${room.year}:${policyIndex}:${twistIndex}`,
      title: `${policy} ${twist} during chapter ${room.year}`,
      desc: `${policyDesc} ${twistDesc}`,
      delta,
    };
  })));
  room.currentChoices = new Map();
  room.players.forEach((player, index) => room.currentChoices.set(player.id, deck.slice(index * CHOICES_PER_PLAYER, (index + 1) * CHOICES_PER_PLAYER)));
}

function nextEvent(room, driver) {
  const chapter = storyChapters[room.year - 1];
  const choice = driver.lastChoice || { title: "the unanswered emergency plan" };
  return {
    ...chapter,
    chapter: room.year + 1,
    cause: { playerName: driver.name, answer: choice.title },
    desc: `${chapter.desc} This chapter exists because ${driver.name} chose “${choice.title}”.`,
    question: `${chapter.question} The room is now stuck with “${choice.title}” — what happens next?`,
  };
}

function publicRoom(room, viewer) {
  return {
    code: room.code,
    status: room.status,
    year: room.year,
    totalYears: room.totalYears,
    event: room.event,
    deadlineAt: room.deadlineAt,
    answerTimeMs: TURN_TIME_MS,
    serverTime: Date.now(),
    isHost: viewer.id === room.hostId,
    players: room.players.map((player) => ({
      id: player.id,
      name: player.name,
      connected: player.connected,
      hasChosen: player.choices[room.year - 1] !== undefined,
      score: score(player),
      state: player.state,
    })),
    myChoices: room.currentChoices?.get(viewer.id) || [],
    results: room.status === "finished" ? room.players.map((player) => ({
      name: player.name,
      score: score(player),
      state: player.state,
      choices: player.choices,
    })).sort((a, b) => b.score - a.score) : undefined,
  };
}

function emitRoom(io, room) {
  room.players.forEach((player) => {
    if (player.connected && player.socketId) io.to(player.socketId).emit("room:update", publicRoom(room, player));
  });
}

function finishOrAdvance(io, room) {
  if (!room.players.every((player) => player.choices[room.year - 1] !== undefined)) return;
  if (room.turnTimer) clearTimeout(room.turnTimer);
  room.deadlineAt = null;
  if (room.year >= room.totalYears) {
    room.status = "finished";
    room.currentChoices = new Map();
    emitRoom(io, room);
    return;
  }
  const driver = room.players[(room.year - 1) % room.players.length];
  const upcomingEvent = nextEvent(room, driver);
  room.year += 1;
  room.event = upcomingEvent;
  makeChoices(room);
  room.deadlineAt = Date.now() + TURN_TIME_MS;
  room.turnTimer = setTimeout(() => {
    room.players.forEach((player) => {
      if (player.choices[room.year - 1] !== undefined) return;
      const choices = room.currentChoices.get(player.id) || [];
      if (choices.length) {
        const choiceIndex = randomInt(choices.length);
        applyChoice(player, choices[choiceIndex], choiceIndex, room.year);
      }
    });
    finishOrAdvance(io, room);
  }, TURN_TIME_MS);
  emitRoom(io, room);
}

function startRound(io, room) {
  makeChoices(room);
  room.deadlineAt = Date.now() + TURN_TIME_MS;
  room.turnTimer = setTimeout(() => {
    room.players.forEach((player) => {
      if (player.choices[room.year - 1] !== undefined) return;
      const choices = room.currentChoices.get(player.id) || [];
      if (choices.length) {
        const choiceIndex = randomInt(choices.length);
        applyChoice(player, choices[choiceIndex], choiceIndex, room.year);
      }
    });
    finishOrAdvance(io, room);
  }, TURN_TIME_MS);
  emitRoom(io, room);
}

function makePlayer(name, socket, resumeToken) {
  return {
    id: randomUUID(),
    name: cleanName(name),
    state: baseState(),
    choices: [],
    lastChoice: null,
    connected: true,
    socketId: socket.id,
    resumeTokenHash: createHash("sha256").update(resumeToken).digest("hex"),
  };
}

export function attachGameServer(httpServer) {
  const io = new Server(httpServer, { path: "/api/socket.io", transports: ["websocket", "polling"] });

  io.on("connection", (socket) => {
    socket.on("room:create", (payload = {}, ack = () => {}) => {
      const resumeToken = randomBytes(32).toString("hex");
      const host = makePlayer(payload.name, socket, resumeToken);
      const totalYears = [10, 15, 20].includes(Number(payload.totalYears)) ? Number(payload.totalYears) : 20;
      const code = makeCode();
      const room = { code, hostId: host.id, players: [host], status: "lobby", year: 1, totalYears, event: openingEvent, currentChoices: new Map(), deadlineAt: null, turnTimer: null };
      rooms.set(code, room);
      socket.data.room = code;
      socket.data.player = host.id;
      socket.join(code);
      ack({ ok: true, code, playerId: host.id, resumeToken });
      emitRoom(io, room);
    });

    socket.on("room:join", (payload = {}, ack = () => {}) => {
      const room = rooms.get(String(payload.code || "").trim().toUpperCase());
      if (!room) return ack({ ok: false, error: "Room code not found." });
      if (room.status !== "lobby") return ack({ ok: false, error: "This game has already started." });
      if (room.players.length >= MAX_PLAYERS) return ack({ ok: false, error: `Room is full (maximum ${MAX_PLAYERS} players).` });
      const resumeToken = randomBytes(32).toString("hex");
      const player = makePlayer(payload.name, socket, resumeToken);
      room.players.push(player);
      socket.data.room = room.code;
      socket.data.player = player.id;
      socket.join(room.code);
      ack({ ok: true, code: room.code, playerId: player.id, resumeToken });
      emitRoom(io, room);
    });

    socket.on("room:resume", (payload = {}, ack = () => {}) => {
      const room = rooms.get(String(payload.code || "").trim().toUpperCase());
      const tokenHash = typeof payload.resumeToken === "string" ? createHash("sha256").update(payload.resumeToken).digest("hex") : "";
      const player = room?.players.find((candidate) => candidate.resumeTokenHash === tokenHash);
      if (!room || !player) return ack({ ok: false, error: "That saved session is no longer valid." });
      player.connected = true;
      player.socketId = socket.id;
      socket.data.room = room.code;
      socket.data.player = player.id;
      socket.join(room.code);
      ack({ ok: true, code: room.code, playerId: player.id, isHost: player.id === room.hostId });
      emitRoom(io, room);
    });

    socket.on("game:start", (_payload = {}, ack = () => {}) => {
      const room = rooms.get(socket.data.room);
      const player = room?.players.find((candidate) => candidate.id === socket.data.player);
      if (!room || !player) return ack({ ok: false, error: "Join or resume a room first." });
      if (player.id !== room.hostId) return ack({ ok: false, error: "Only the room host can start." });
      if (room.status !== "lobby") return ack({ ok: false, error: "This game has already started." });
      if (room.players.filter((candidate) => candidate.connected).length < 2) return ack({ ok: false, error: "Invite at least one connected player first." });
      room.status = "playing";
      startRound(io, room);
      ack({ ok: true });
    });

    socket.on("game:choose", (payload = {}, ack = () => {}) => {
      const room = rooms.get(socket.data.room);
      const player = room?.players.find((candidate) => candidate.id === socket.data.player);
      if (!room || room.status !== "playing" || !player) return ack({ ok: false, error: "Game is not in progress." });
      if (Number(payload.year) !== room.year) return ack({ ok: false, error: "That chapter has ended. Your game is being updated." });
      if (player.choices[room.year - 1] !== undefined) return ack({ ok: false, error: "You already chose this chapter." });
      const choices = room.currentChoices.get(player.id) || [];
      const choiceIndex = Number(payload.choiceIndex);
      if (!Number.isInteger(choiceIndex) || !choices[choiceIndex]) return ack({ ok: false, error: "Invalid choice." });
      applyChoice(player, choices[choiceIndex], choiceIndex, room.year);
      ack({ ok: true });
      finishOrAdvance(io, room);
      if (room.status === "playing" && room.players.some((candidate) => candidate.choices[room.year - 1] === undefined)) emitRoom(io, room);
    });

    socket.on("disconnect", () => {
      const room = rooms.get(socket.data.room);
      const player = room?.players.find((candidate) => candidate.id === socket.data.player);
      if (!player || player.socketId !== socket.id) return;
      player.connected = false;
      player.socketId = null;
      emitRoom(io, room);
      if (room.players.every((candidate) => !candidate.connected)) {
        setTimeout(() => {
          if (room.players.every((candidate) => !candidate.connected)) rooms.delete(room.code);
        }, ROOM_TTL_MS).unref?.();
      }
    });
  });
}